TIGER PRIME — Netlify + Gemini backend (Android phone setup)

FILES
- public/index.html                 Website UI (updated file)
- netlify/functions/predict.mjs     Secure Gemini backend; API key is NOT in HTML
- netlify.toml                      Netlify build settings

IMPORTANT
A normal manual drag-and-drop static deploy may not deploy serverless functions. Use GitHub-connected deploy or Netlify CLI. This bundle is arranged for GitHub-connected deploy.

ANDROID PHONE SETUP
1. Download and extract this ZIP on your phone (Files app / a ZIP extractor).
2. Open https://github.com in Chrome and sign in.
3. Create a NEW repository, e.g. tiger-prime-netlify. Keep it private if you prefer.
4. Upload the CONTENTS of this folder, preserving the structure exactly:
   public/index.html
   netlify/functions/predict.mjs
   netlify.toml
   Do not upload a ZIP as the only repository file. GitHub web upload may require selecting files/folders in desktop mode; if folders are difficult, use GitHub's web editor to create each file at the exact path.
5. Open https://app.netlify.com and sign in.
6. Add new site / Import an existing project, choose GitHub, select your repository, and deploy. Netlify reads netlify.toml and deploys the function.
7. In Netlify, open the site -> Project configuration -> Environment variables. Add:
   Key: GEMINI_API_KEY
   Value: (paste your Gemini API key privately)
   Optional: GEMINI_MODEL = gemini-3.8-flash (this is the default; set only if you need to override it).
8. Save the variable and trigger a new deploy. Variables must be present at deploy time for functions.
9. Open https://YOUR-SITE.netlify.app/.netlify/functions/predict
   Expected JSON status includes "Backend ready" and configured:true.
10. Open your site homepage. In TIGER PRIME, AI backend status should show that Gemini is configured/connected after it makes a prediction request.

GETTING THE KEY
Open https://aistudio.google.com/apikey, sign in, create an API key, and keep it secret. Current Google AI Studio may create authorization keys by default. If the key is rejected by the REST endpoint, check the key type, API access, and the current Gemini API documentation; never paste the key into chat or into index.html.

SECURITY
- Never place the key in public/index.html or any JavaScript sent to the browser.
- Never commit the key to GitHub.
- Use Netlify environment variables only.
- Check Gemini quotas/pricing; free usage is subject to availability and limits.
- AI output is statistical commentary, not a reliable or guaranteed forecast of random draws.

TROUBLESHOOTING
- 404 at /.netlify/functions/predict: the function was not deployed; check repository paths and Netlify build/deploy log.
- configured:false or missing-key message: add GEMINI_API_KEY in Netlify and redeploy.
- 429: Gemini quota/rate limit reached.
- 400/401/403 from Gemini: check API key type, project/API access, model availability, and current Google Gemini documentation.
