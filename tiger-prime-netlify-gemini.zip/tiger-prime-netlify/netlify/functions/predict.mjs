const JSON_HEADERS = { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' };

function json(body, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: JSON_HEADERS });
}

function safeString(value, max = 160) {
  return String(value ?? '').replace(/[<>]/g, '').slice(0, max);
}

export default async (request) => {
  if (request.method === 'GET') {
    return json({
      status: process.env.GEMINI_API_KEY ? 'Backend ready • Gemini key detected' : 'Backend deployed • GEMINI_API_KEY missing',
      provider: 'Gemini',
      configured: Boolean(process.env.GEMINI_API_KEY)
    });
  }

  if (request.method !== 'POST') {
    return json({ error: 'Method not allowed. Use GET or POST.' }, 405);
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return json({ error: 'Gemini API key is not configured. Add GEMINI_API_KEY in Netlify environment variables and redeploy.' }, 503);
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return json({ error: 'Request body must be valid JSON.' }, 400);
  }

  const rawHistory = Array.isArray(body.history) ? body.history : [];
  const history = rawHistory.slice(0, 80).map((item) => ({
    period: safeString(item?.period, 40),
    number: Number(item?.number),
    size: Number(item?.number) >= 5 ? 'BIG' : 'SMALL'
  })).filter((item) => Number.isInteger(item.number) && item.number >= 0 && item.number <= 9);

  if (history.length < 8) {
    return json({ error: 'At least 8 valid recent results are required.' }, 400);
  }

  const stats = body.statistics && typeof body.statistics === 'object' ? body.statistics : {};
  const compactStats = {
    recentBig: Number(stats.big) || 0,
    recentSmall: Number(stats.small) || 0,
    big50: Number(stats.big50) || 0,
    small50: Number(stats.small50) || 0,
    big100: Number(stats.big100) || 0,
    small100: Number(stats.small100) || 0,
    currentStreak: safeString(stats.lastSize, 10),
    streakLength: Number(stats.streak) || 0,
    transitionSamples: Number(stats.transitionTotal) || 0,
    alternationRate: Number(stats.alternationRate) || 0,
    hotNumbers: Array.isArray(stats.hot) ? stats.hot.slice(0, 3) : [],
    coldNumbers: Array.isArray(stats.cold) ? stats.cold.slice(0, 3) : []
  };

  const prompt = `You are a cautious statistical analyst for a random Big/Small number game. Numbers 0-4 mean SMALL; 5-9 mean BIG. Analyze the supplied past results and descriptive statistics. Do not claim certainty, do not invent external/live data, and do not describe confidence as a real win probability. Random draws may be independent, so patterns may have no predictive value. Return ONLY a JSON object with exactly these keys: lean (BIG or SMALL), confidence (integer 0-100 representing strength of evidence only, not probability of winning), analysis (brief plain text, max 500 characters). If evidence is weak or balanced, still choose the side with the slight statistical lean, but clearly say evidence is weak in analysis. Use only this input.

Issue requested: ${safeString(body.issueId, 60)}
History newest first: ${JSON.stringify(history)}
Descriptive statistics: ${JSON.stringify(compactStats)}`;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 18000);
  try {
    const model = process.env.GEMINI_MODEL || 'gemini-3.8-flash';
    const upstream = await fetch('https://generativelanguage.googleapis.com/v1beta/interactions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
      body: JSON.stringify({
        model,
        input: prompt,
        temperature: 0.2
      }),
      signal: controller.signal
    });

    const result = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      const providerMessage = safeString(result?.error?.message || `Gemini HTTP ${upstream.status}`, 300);
      return json({ error: `Gemini API error: ${providerMessage}` }, upstream.status === 429 ? 429 : 502);
    }

    const answer = String(result?.output_text || result?.output?.map((item) => item?.content?.map((part) => part?.text || '').join('')).join('\n') || '');
    let parsed;
    try {
      const match = answer.match(/\{[\s\S]*\}/);
      if (!match) throw new Error('No JSON object returned');
      parsed = JSON.parse(match[0]);
    } catch {
      return json({ error: 'Gemini returned an unreadable response. Please retry.' }, 502);
    }

    const rawLean = String(parsed.lean || '').toUpperCase();
    const lean = rawLean === 'BIG' ? 'BIG' : rawLean === 'SMALL' ? 'SMALL' : null;
    if (!lean) return json({ error: 'Gemini response did not contain a valid BIG/SMALL signal.' }, 502);

    const confidence = Math.max(0, Math.min(100, Math.round(Number(parsed.confidence) || 0)));
    const details = safeString(parsed.analysis || 'AI reviewed the submitted history; this is not a guaranteed forecast.', 500);
    return json({
      results: [{ provider: 'Gemini', lean, confidence, details }],
      issueId: safeString(body.issueId, 60),
      disclaimer: 'Evidence score is not a win probability. Random outcomes cannot be predicted with certainty.'
    });
  } catch (error) {
    const message = error?.name === 'AbortError' ? 'Gemini request timed out. Try again.' : safeString(error?.message || 'Unexpected backend error', 250);
    return json({ error: message }, 502);
  } finally {
    clearTimeout(timeout);
  }
};
